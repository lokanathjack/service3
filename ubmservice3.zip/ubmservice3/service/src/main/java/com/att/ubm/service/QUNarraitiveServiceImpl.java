/**
 * 
 */
package com.att.ubm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.ubm.camunda.CamundaUBMComponent;
import com.att.ubm.dao.IQUNarraitiveDAO;
import com.att.ubm.model.AlternateName;
import com.att.ubm.model.ApprovalName;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.CamundaActionModel;
import com.att.ubm.model.CamundaModel;
import com.att.ubm.model.ChannelName;
import com.att.ubm.model.ProductName;
import com.att.ubm.model.QUNarrativeModel;
import com.att.ubm.model.QuickUpdate;
import com.att.ubm.model.Voice;
import com.att.ubm.util.QUNarrativeConstants;
import com.att.aft.dme2.internal.jettison.json.JSONArray;
import com.att.it.tdc.bpm.service.task.ITaskService;
import com.att.it.tdc.bpm.service.task.impl.TaskServiceCamundaImpl;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.DeserializationFeature;

import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

/**
 * @author kb942m
 *
 */
@Service(value = "quNarraitiveService")
public class QUNarraitiveServiceImpl implements IQUNarraitiveService {

	private static final Logger logger = LoggerFactory.getLogger(QUNarraitiveServiceImpl.class);
	private String VALUE="value";
	private String TYPE="type";

	@Autowired
	IQUNarraitiveDAO quNarraitiveDAO;
	
	@Autowired
	CamundaUBMComponent camundaComponent; 
	
	@Override
	public ApprovalOption getApproverOptionsInfo( List<ApprovalName> approvalNameMapList, String sidType,
			String sidId) {
		ApprovalOption approvalOption = null;
		QuickUpdate quickUpdate = null;
		Voice voice = null;
		List<ProductName> productNameList = new ArrayList<ProductName>();
		List<ChannelName> channelNameList = new ArrayList<ChannelName>();
		List<AlternateName> alternateNameList = new ArrayList<AlternateName>();
		ProductName productName = null;
		ChannelName channelName = null;
		AlternateName alternateName = null;
		String apprName = "";
		try {
			approvalOption = new ApprovalOption();
			quickUpdate = new QuickUpdate();	
			voice = new Voice();
			String name = "";
		if (approvalNameMapList != null && !approvalNameMapList.isEmpty()) {
			for (ApprovalName approvalNameModel : approvalNameMapList) {
				/*if (Long.parseLong(sidId) >= approvalNameModel.getStartDisplay()
						&& Long.parseLong(sidId) <= approvalNameModel.getEndDisplay()) {*/
					apprName = approvalNameModel.getName().substring(0, 7);
					if (approvalNameModel.getName() != null && !approvalNameModel.getName().isEmpty()) {
						name = approvalNameModel.getName().substring(8);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.PRODUCT)) {
						productName = new ProductName();
						productName.setFirstName(approvalNameModel.getFirstName());
						productName.setLastName(approvalNameModel.getLastName());
						productName.setUserName(approvalNameModel.getAttId());
						productName.setName(name);
						productNameList.add(productName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.CHANNEL)) {

						channelName = new ChannelName();
						channelName.setFirstName(approvalNameModel.getFirstName());
						channelName.setLastName(approvalNameModel.getLastName());
						channelName.setUserName(approvalNameModel.getAttId());
						channelName.setName(name);
						channelNameList.add(channelName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.ALTERNATE)) {
						apprName = approvalNameModel.getName().substring(0, 9);	
						alternateName = new AlternateName();
						alternateName.setFirstName(approvalNameModel.getFirstName());
						alternateName.setLastName(approvalNameModel.getLastName());
						alternateName.setUserName(approvalNameModel.getAttId());
						alternateName.setName(name);
						alternateNameList.add(alternateName);
					}
				//}
				if(sidType.equalsIgnoreCase("QUICKUPDATE")){
					quickUpdate.setProduct(productNameList);
					quickUpdate.setChannel(channelNameList);
					quickUpdate.setAlternate(alternateNameList);				
					approvalOption.setQuickUpdate(quickUpdate);
				}else if(sidType.equalsIgnoreCase("Voice")){					
					voice.setProduct(productNameList);
					voice.setChannel(channelNameList);
					voice.setAlternate(alternateNameList);				
					approvalOption.setVoice(voice);
				}
				
			}
			
		}
		
	}catch (Exception e) {
		logger.error("Exception={}", e.getMessage(), e);
	}
		
		return approvalOption;
	}

	@Override
	public String saveNarrativeForm(String quNarrativeString) {
		 
		try {
			if(quNarrativeString!=null)
			{
				/* JSONArray jsonArr = new JSONArray(quNarrativeString);
				 //System.out.println("Json array:\t"+jsonArr.get(0).toString());
				 ObjectMapper objectMapper = new ObjectMapper();
					objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
					objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
					 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				 QUNarrativeModel baseJsonString=objectMapper.readValue(jsonArr.get(0).toString(),QUNarrativeModel.class);
				 QUNarrativeModel newJsonString=objectMapper.readValue(jsonArr.get(1).toString(),QUNarrativeModel.class);
				 JsonNode expectedNode = objectMapper.readTree(objectMapper.writeValueAsString(baseJsonString));
					JsonNode actualNode = objectMapper.readTree(objectMapper.writeValueAsString(newJsonString));
					//boolean areEqual = expectedNode.equals(actualNode);
					//System.out.println(areEqual);
					JSONCompareResult result = 
						     JSONCompare.compareJSON(jsonArr.get(0).toString(), jsonArr.get(1).toString(), JSONCompareMode.STRICT);
						System.out.println(result.toString());*/
				JSONArray jsonArr = new JSONArray(quNarrativeString);
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				 QUNarrativeModel quNarrativeModel=null;
				 System.out.println(jsonArr.length()+"::::::::::::::::::::");
				 int retVal;
				 boolean camundaFlag=false;
				 if(jsonArr.length()>0)
				 {
					 
					 quNarrativeModel=objectMapper.readValue(jsonArr.get(1).toString(), QUNarrativeModel.class);
				 }
				if(quNarrativeModel!=null && !quNarraitiveDAO.rowExists(QUNarrativeConstants.QU_TABLE_NAME, quNarrativeModel.getSidId()))
				{
					System.out.println("getRequestedDate:\t"+quNarrativeModel.getNarrative().getRequestedDate());
					retVal=quNarraitiveDAO.insertNarrativeForm(QUNarrativeConstants.QU_TABLE_NAME,quNarrativeModel);
					if(retVal>0)
					{
						
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "MARKETS", quNarrativeModel.getNarrative().getMarkets(),quNarrativeModel.getCreator());
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "REQUIRED APPROVER", quNarrativeModel.getNarrative().getRequiredCoreApproval(),quNarrativeModel.getCreator());
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "OPTIONAL APPROVER", quNarrativeModel.getNarrative().getProductApprovers(),quNarrativeModel.getCreator());
					}
					camundaFlag=makePostCall(quNarrativeModel);
					if(camundaFlag)
					{
						return "Task "+ quNarrativeModel.getActivity() +" has been successfully completed";
					}
					
					
				}
				else
				{
					System.out.println("Record exists");

					if(quNarrativeModel!=null)
					{
						
						String baseString=jsonArr.get(0).toString();
						System.out.println("baseString:\t"+baseString);
						String userModifeidString=jsonArr.get(1).toString();
						System.out.println("userModifeidString:\t"+userModifeidString);
						JSONCompareResult result = 
						     JSONCompare.compareJSON(removeMultiselectArray(quNarrativeModel.getSidType(),userModifeidString),removeMultiselectArray(quNarrativeModel.getSidType(),baseString), JSONCompareMode.STRICT);
						if(result!=null)
						{
								List<FieldComparisonFailure> diffValues=result.getFieldFailures();
								if(diffValues!=null && diffValues.size()>0)
								{
									Map<String,String> jsonDbMapping=quNarraitiveDAO.getJsonDBMapping(quNarrativeModel.getSidType());
									Map<String,Object> updateNarrativeParams=new LinkedHashMap<String,Object>();
									StringBuffer sb=new StringBuffer("update SID_NARR set ");
									StringBuffer tempSb=new StringBuffer();
										for(FieldComparisonFailure obj:diffValues)
										{
											System.out.println("FieldName:\t"+obj.getField());
											System.out.println("Actual:\t"+obj.getActual());
											System.out.println("Expected:\t"+obj.getExpected());
											if(jsonDbMapping!=null && jsonDbMapping.size()>0 && jsonDbMapping.containsKey(obj.getField()))
											{
												updateNarrativeParams.put(jsonDbMapping.get(obj.getField()), obj.getExpected());
												sb.append(jsonDbMapping.get(obj.getField())+"=:"+jsonDbMapping.get(obj.getField()));
												sb.append(",");
											}
										}
										System.out.println(sb+"::::::::");
										tempSb.append(sb.toString().endsWith(",") ? sb.substring(0, sb.length()-1): sb.toString());
										//String testStr=tempStr+" where SID_ID="+Long.parseLong(quNarrativeModel.getSidId())+ " and SID_TYPE='"+quNarrativeModel.getSidType()+"' and REQ_TYPE='"+quNarrativeModel.getSidReqType()+"'";
										tempSb.append(" where SID_ID=:SID_ID and SID_TYPE=:SID_TYPE and REQ_TYPE=:REQ_TYPE");
										System.out.println("sb:\t"+tempSb.toString());
										updateNarrativeParams.put("SID_ID", Long.parseLong(quNarrativeModel.getSidId()));
										updateNarrativeParams.put("SID_TYPE", quNarrativeModel.getSidType());
										updateNarrativeParams.put("REQ_TYPE", quNarrativeModel.getSidReqType());
										retVal=quNarraitiveDAO.updateNarrativeForm("SID_NARR", tempSb.toString(),updateNarrativeParams); 	
										//both insert and update narrative method make as a single method in furture
										
											quNarraitiveDAO.deleteMultiSelectRow(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "MARKETS", quNarrativeModel.getNarrative().getMarkets(),quNarrativeModel.getCreator());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "REQUIRED APPROVER", quNarrativeModel.getNarrative().getRequiredCoreApproval(),quNarrativeModel.getCreator());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "OPTIONAL APPROVER", quNarrativeModel.getNarrative().getProductApprovers(),quNarrativeModel.getCreator());
										
										}
									
								makePostCall(quNarrativeModel);
								if(camundaFlag)
								{
									return "Task "+ quNarrativeModel.getActivity() +" has been successfully completed";
								}
								
								}
					
						}
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception={}", e.getMessage(), e);
			return null;
		}
		return null;

	}
	@Override
	public String getNarrativeFormValues(String sidId) {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		 QUNarrativeModel quNarrativeModel=quNarraitiveDAO.getNarrativeFormValues(sidId);
		 String quNarrativeModelString=null;
		try {
			quNarrativeModelString = objectMapper.writeValueAsString(quNarrativeModel);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
			if(quNarrativeModel!=null)
			{
				System.out.println("getRequestedDate:\t"+quNarrativeModelString);
			}
			return quNarrativeModelString;
	}
	
	private String removeMultiselectArray(String sidType,String orginalString) throws Exception
	{
		Map<String,String> listOfJsonListName=quNarraitiveDAO.getMultiSelectJsonIgnoreColumns(sidType);
		org.json.JSONObject beforeJo=new org.json.JSONObject(orginalString);
		if(listOfJsonListName!=null)
		{
		for ( String key : listOfJsonListName.keySet() ) {
			beforeJo.remove(key);
		}
		}
		
		
		return beforeJo.toString();
	}
	
	public String camundaApiService(QUNarrativeModel quNarrativeModel) {
		CamundaModel model=new CamundaModel();
		CamundaActionModel camundaActionModel=new CamundaActionModel();
		camundaActionModel.setActionTaken(mappingPostSubmit(quNarrativeModel.getActionTaken()));
		if(quNarrativeModel.getNarrative().getRequestorName()!=null && quNarrativeModel.getNarrative().getRequestorName().contains(":"))
		{
			String requestorId=quNarrativeModel.getNarrative().getRequestorName().split(":")[1];
			camundaActionModel.setRequestor(mappingPostSubmit(requestorId));
		}
		else
		{
		camundaActionModel.setRequestor(mappingPostSubmit(null));
		}
		camundaActionModel.setCreator(mappingPostSubmit(quNarrativeModel.getUserIdTakingAction()));
		camundaActionModel.setSidId(mappingPostSubmit(quNarrativeModel.getSidId()));
		camundaActionModel.setSidDesc(mappingPostSubmit(quNarrativeModel.getSidDescription()));
		camundaActionModel.setSidType(mappingPostSubmit(quNarrativeModel.getSidType()));
		camundaActionModel.setRequestType(mappingPostSubmit(quNarrativeModel.getSidReqType()));
		model.setVariables(camundaActionModel);
		model.setBusinessKey(quNarrativeModel.getSidId());
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		 String camundaJsonString=null;
		 
		try {
			camundaJsonString = objectMapper.writeValueAsString(model);
			if(camundaJsonString!=null && camundaJsonString.length()>0)
				return camundaJsonString;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public Map<String,String> mappingPostSubmit(String value)
	{
		Map<String,String> map=new HashMap<String,String>();
		map.put(VALUE, value);
		map.put(TYPE, "String");
		return map;
	}
	
	private boolean makePostCall(QUNarrativeModel quNarrativeModel)
	{
		try {
			if(quNarrativeModel!=null)
			{
				String camundaJsonStr=camundaApiService(quNarrativeModel);
				ITaskService taskService = new TaskServiceCamundaImpl();
				taskService = camundaComponent.getCamundaTaskService("vs252n");
				System.out.println("Vlaue of JSON request :::::::::::::: " + camundaJsonStr);
				// TODO Auto-generated method stub
				Boolean ret = taskService.start("mobility", camundaJsonStr);	
				System.out.println(ret);
				return ret;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String getColumnValueFromSidNarr(String sidId, String columnName) {
		// TODO Auto-generated method stub
		String retVal=quNarraitiveDAO.getColumnValueFromSidNarr(sidId, columnName);
		return retVal;
	}

}
