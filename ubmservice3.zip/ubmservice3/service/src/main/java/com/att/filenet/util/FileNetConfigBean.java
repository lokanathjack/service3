package com.att.filenet.util;

public class FileNetConfigBean {
	
	private String webServiceURL;
	private String mechId;
	private String password;
	private String objectStore;
	private String pathFolder;
	private String webURL;
	private String reachableFlag;
	public String getWebServiceURL() {
		return webServiceURL;
	}
	public void setWebServiceURL(String webServiceURL) {
		this.webServiceURL = webServiceURL;
	}
	public String getMechId() {
		return mechId;
	}
	public void setMechId(String mechId) {
		this.mechId = mechId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getObjectStore() {
		return objectStore;
	}
	public void setObjectStore(String objectStore) {
		this.objectStore = objectStore;
	}
	public String getPathFolder() {
		return pathFolder;
	}
	public void setPathFolder(String pathFolder) {
		this.pathFolder = pathFolder;
	}
	public String getWebURL() {
		return webURL;
	}
	public void setWebURL(String webURL) {
		this.webURL = webURL;
	}
	public String isReachableFlag() {
		return reachableFlag;
	}
	public void setReachableFlag(String reachableFlag) {
		this.reachableFlag = reachableFlag;
	}
	
	

}
