/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class MyTaskInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1487090022217465081L;
	private String id;
	private String taskName;
	private String creator;
	private String sidType;
	private String sidId;
	private String sidDescription;
	private String requestType;
	private String impactedGroupName;
	private String assignmentDate;
	private String dueDate;
	private boolean dueFlag;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	
	public String getSidType() {
		return sidType;
	}

	public void setSidType(String sidType) {
		this.sidType = sidType;
	}

	public String getSidId() {
		return sidId;
	}

	public void setSidId(String sidId) {
		this.sidId = sidId;
	}

	public String getSidDescription() {
		return sidDescription;
	}

	public void setSidDescription(String sidDescription) {
		this.sidDescription = sidDescription;
	}

		
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getImpactedGroupName() {
		return impactedGroupName;
	}

	public void setImpactedGroupName(String impactedGroupName) {
		this.impactedGroupName = impactedGroupName;
	}

	public String getAssignmentDate() {
		return assignmentDate;
	}

	public void setAssignmentDate(String assignmentDate) {
		this.assignmentDate = assignmentDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	

	public boolean isDueFlag() {
		return dueFlag;
	}

	public void setDueFlag(boolean dueFlag) {
		this.dueFlag = dueFlag;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
