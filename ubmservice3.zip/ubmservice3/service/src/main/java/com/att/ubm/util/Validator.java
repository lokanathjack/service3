package com.att.ubm.util;

import java.lang.reflect.Array;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.Validator;

public final class Validator {


/**
 * Validator constructor comment.
 */
private Validator() {
	super();
}


/**
 * Check if double > 0.0
 * @return boolean
 */
public static final boolean isPresent(double in)
{
	if ( in > 0.0 )
		return true;
	else
		return false;
}


/**
 * Check if int > 0
 * @return boolean
 */
public static final boolean isPresent(int in)
{
	if ( in > 0 )
		return true;
	else
		return false;
}

/**
 * Check if string = "" or = "0" or = "0.0" or = "0.00"
 * @return boolean
 */
public static final boolean isPresent(String in)
{
	if ( (in == null) || (in.trim().length() == 0) )
		return false;
	else
		return true;
}


/**
 * Check if string = "a..z" or = "0..9" or = "A..Z" only
 * @return boolean
 */
public static final boolean isValidAlphaNum(String str)
{
	String sValidchars = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String sTemp;

	// Check if str is not null
	if (! isValidString(str) )
		return false;


	// Check if str contains any char other than alpha-numerics
	for (int i=0; i<str.length(); i++)
	{
		sTemp = "" + str.substring(i, i+1);
		if (sValidchars.indexOf(sTemp) == -1)
			return false;
	}

	return true;
}


/**
 * Check if parameter object passed is valid array
 * and there is at least one non-null element in the array
 * @return boolean
 */
public static final boolean isValidArray(Object argArr)
{
	if (argArr == null)
		return false;

	//Check if an Object is an Array
	if (!argArr.getClass().isArray())
		return false;

	//Check if array has elements
	if (Array.getLength(argArr) < 1 )
		return false;

	//Check if each array element is valid
	for (int i=0; i<Array.getLength(argArr); i++)
	{
		if ( Array.get(argArr, i) != null )
			return true;
	}

	return false;
}

public static final boolean isValidArrayList(ArrayList argArrayList)
{
	if (argArrayList == null)
		return false;

	//Check if array has elements
	if (argArrayList.size() < 1 )
		return false;

	//Check if each array element is valid
	if ( argArrayList.get(0) != null )
		return true;

	return false;
}

public static final boolean isValidList(List argList)
{
	if (argList == null || argList.isEmpty() )
		return false;

	//Check if each array element is valid
	if ( argList.get(0) != null )
		return true;

	return false;
}

/**
 * Check if credit card expiry date has not expired
 * @return boolean
 */
public static final boolean isValidCCExpiryDate(int iYear, int iMonth)
{
	Date dtCC = new Date();
	if ( ! DecoratorDate.intToDateYMD(iYear, iMonth, 1, dtCC) )
		return false;

	Date dtNow      = DecoratorDate.getCurrentDateTimestamp();
	int  iThisYear  = DecoratorDate.dateToComponent(dtNow, Calendar.YEAR);
	int  iThisMonth = DecoratorDate.dateToComponent(dtNow, Calendar.MONTH);

	DecoratorDate.intToDateYMD(iThisYear, iThisMonth, 1, dtNow);

	if ( dtCC.before(dtNow) )
		return false;

	return true;
}


/**
 * Verify credit card number
 * @return boolean
 */
public static final boolean isValidCCLuhn(String sCCNumber)
{
	// Check if str is not null
	if (! isValidString(sCCNumber) )
		return false;


	// Check if str is valid number
    sCCNumber = sCCNumber.trim();
    if ( ! Validator.isValidLong(sCCNumber))
    	return false;


    StringBuffer cardNumberBuffer = new StringBuffer(sCCNumber);

    int iCardIndex = sCCNumber.length();
    int iOddOrEven = iCardIndex & 1;
    int iSum       = 0;

    char eachNumber[] = new char[1];

    for (int iCount = 0; iCount < iCardIndex; iCount++)
    {
    	eachNumber[0] = cardNumberBuffer.charAt(iCount);

      	int iDigit = Integer.parseInt(new String(eachNumber));

      	if (((iCount & 1) ^ iOddOrEven) == 0)
      	{
        	iDigit *= 2;
        	if (iDigit > 9)
          		iDigit -= 9;
      	}
      	iSum += iDigit;
    }

    if (iSum % 10 == 0)
      	return true;
    else
      	return false;
}


/**
 * Verify if credit card type is consistent with its number
 * @return boolean
 */
public static final boolean isValidCCType(String sCardType, String sCardNumber)
{
    sCardNumber = sCardNumber.trim();

    if (sCardType.equalsIgnoreCase("VISA"))
    {
      	if ( (sCardNumber.length() == 13 || sCardNumber.length() == 16) &&
	      	  sCardNumber.startsWith("4") )
        	return true;
      	else
        	return false;
    }

    else if (sCardType.equalsIgnoreCase("MAST"))
    {
      	if ( sCardNumber.length() == 16 &&
	        (sCardNumber.startsWith("51") || sCardNumber.startsWith("52") ||
		     sCardNumber.startsWith("53") || sCardNumber.startsWith("54") ||
		     sCardNumber.startsWith("55")
		    ))
        	return true;
      	else
        	return false;
    }

    else if (sCardType.equalsIgnoreCase("DISC"))
    {
      	if ( sCardNumber.length() == 16 &&
	      	 sCardNumber.startsWith("6011"))
        	return true;
      	else
        	return false;
    }

    else if (sCardType.equalsIgnoreCase("AMEX"))
    {
      	if ( sCardNumber.length() == 15 &&
	      	(sCardNumber.startsWith("34") || sCardNumber.startsWith("37")))
        	return true;
      	else
        	return false;
    }


    return false;
}


/**
 * Check if string = "000.00"
 * @return boolean
 */
public static final boolean isValidDecimal2(String str)
{
	// Check is str is not null
	if ( ! isValidString(str) )
		return false;


	// Check is valid double
	if ( ! isValidDouble(str) )
		return false;


	if (str.indexOf('.') == -1)
		return true;


	int iDecAllowed = 2;

	String sDectext = str.substring(str.indexOf('.')+1, str.length() );

	if (sDectext.length() > iDecAllowed)
		return false;


	return true;
}


/**
 * Check if string is valid double
 * @return boolean
 */
public static final boolean isValidDouble(String str)
{
	// Check is str is not null
	if ( ! isValidString(str) )
		return false;


	// Convert and check
	try
	{
		Double dbl = Double.valueOf(str);

		if ( dbl.isNaN() || dbl.isInfinite() )
			return false;
	}
	catch (NumberFormatException nfe)
	{
		return false;
	}

	return true;
}


/**
 * Check if string is valid email address
 * @return boolean
 */
public static final boolean isValidEmailAddress(String emailStr)
{
	// Check if str is not null
	if (! isValidString(emailStr))
		return false;

/*	IMPORT JAKARTA RE
	try {

		// The following pattern is used to check if the entered e-mail address
		// fits the user@domain format.
		RE emailPat = new RE("^([^@]+)@([^@]+)$");



		// The following string represents the pattern for matching all special
		// characters.  We don't want to allow special characters in the address.
		// These characters include ( ) < > @ , ; : \ " . [ ]
		String specialChars = "\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";


		// The following string represents the range of characters allowed in a
		// username or domainname.  It really states which chars aren't allowed.
		String validChars = "[^\\s" + specialChars + "]";


		// The following pattern applies if the "user" is a quoted string (in
		// which case, there are no rules about which characters are allowed
		// and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
		// is a legal e-mail address.
		String quotedUser = "(\"[^\"]*\")";


		// The following string represents an atom (basically a series of
		// non-special characters.)
		String atom = validChars + '+';


		// The following string represents one word in the typical username.
		// For example, in john.doe@somewhere.com, john and doe are words.
		// Basically, a word is either an atom or quoted string.
		String word = "(" + atom + "|" + quotedUser + ")";


		// The following pattern describes the structure of the user
		RE userPat = new RE("^" + word + "(\\." + word + ")*$");



		// The following pattern applies for domains that are IP addresses,
		// rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
		// e-mail address. NOTE: The square brackets are required.
		RE ipDomainPat = new RE("^\\[(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\]$");


		// The following pattern describes the structure of a normal symbolic
		// domain, as opposed to ipDomainPat, shown above.
		RE domainPat = new RE("^" + atom + "(\\." + atom +")*$");


		// ---------------------------------------------------------------------------
		// Start Email Validation
		// ---------------------------------------------------------------------------


		// Begin with the coarse pattern to simply break up user@domain into
		// different pieces that are easy to analyze.
		if ( ! emailPat.match(emailStr) )
		{
			// Too many/few @'s
			return false;
		}


		RE emailPat_1 = new RE("@");
		String[] matchArray = emailPat_1.split(emailStr);
		String user   = matchArray[0];
		String domain = matchArray[1];


		// See if "user" is valid
		if ( ! userPat.match(user) )
		{
			return false;
		}



		// if the e-mail address is at an IP address (as opposed to a symbolic
		// host name) make sure the IP address is valid.
		if ( ipDomainPat.match(domain) )
		{
			RE ipDomainPat_1 = new RE("\\.");
			String[] IPArray = ipDomainPat_1.split(domain.substring(1, domain.length()-1));

			if (IPArray.length == 4)
			{
				// this is an IP address
				for (int i=0; i<4; i++)
				{
					if ( ! isValidInteger(IPArray[i]) )
						return false;

					if ( NCDecorator.stringToInt(IPArray[i]) > 255)
					{
						return false;
					}
				}
				return true;
			}
		}


		// Domain is symbolic name
		if ( ! domainPat.match(domain) )
		{
			return false;
		}


		// domain name seems valid, but now make sure that it ends in a
		// three-letter word (like com, edu, gov) or a two-letter word,
		// representing country (uk, nl), and that there's a hostname preceding
		// the domain or country.

		RE domainPat_1 = new RE("\\.");
		String[] domArr = domainPat_1.split(domain);
		int len = domArr.length;

		if (domArr[len-1].length()<2 || domArr[len-1].length()>3)
		{
			// the address must end in a two letter or three letter word.
			return false;
		}

		// Make sure there's a host name preceding the domain.
		if (len<2)
		{
			return false;
		}

		// Address is good
		return true;


	} catch (org.apache.regexp.RESyntaxException e)
	{
		return false;
	}

*/ return false;
}


/**
 * Check if string is valid email address
 * @return boolean
 */
public static final boolean isValidEmailAddressSimple(String emailAddress)
{
	// Check if str is not null
	if (! isValidString(emailAddress))
		return false;


	int len        = emailAddress.length();
	int at1        = emailAddress.indexOf("@");
	int atnext     = emailAddress.indexOf("@", at1);
	int dotAfterat = emailAddress.indexOf(".", at1);
	int dotend     = emailAddress.lastIndexOf(".");
	int atEnd      = emailAddress.lastIndexOf("@");


	// if length of email address is less than 4 characters
	if (len < 4)
		return false;

	// @ symbol not present
	if (at1 < 1)
		return false;

 	// 2 or more @ symbol
 	if (atEnd > at1)
 		return false;

	// No . symbol after @ symbol
 	if (dotAfterat <= at1)
 		return false;

	// No characters between @ symbol and following . symbol
	if (dotAfterat <= at1 + 1)
		return false;

	// No character after last . symbol
	if (dotend >= len)
		return false;


	return true;
}


/**
 * Check if string is valid integer
 * @return boolean
 */
public static final boolean isValidInteger(String str)
{
	// Check if str is not null
	if (! isValidString(str) )
		return false;


	// Convert and check
	try
	{
		Integer.parseInt(str);
	}
	catch (NumberFormatException nfe)
	{
		return false;
	}


	return true;
}

/**
 * Check if string is valid long
 * @return boolean
 */
public static final boolean isValidLong(String str)
{
	// Check if str is not null
	if (! isValidString(str) )
		return false;

	// Convert and check
	try
	{
		Long.parseLong(str);
	}
	catch (NumberFormatException nfe)
	{
		return false;
	}

	return true;
}


/**
 * Check if string is valid (not null and with at least 1 char)
 * @return boolean
 */
public static final boolean isValidString(String str)
{
	if (str == null || str.trim().length() <= 0)
		return false;

	return true;
}

/**
 * Check if string is in this date format MM/DD/YYYY.
 * @return boolean
 */
public static final boolean isValidDate(String str)
{
    if (! isValidString(str) )
            return false;

    str = str.trim();
    if (str.length() - str.lastIndexOf("/") < 5)
    {
        return false;
    }

    java.util.Date tempDate = new java.util.Date();
    if (!DecoratorDate.stringToDateInFormat(str, tempDate, "MM/dd/yyyy", null))
    {
        return false;
    }

    return true;
}

}
