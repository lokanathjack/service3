package com.att.ubm.service;

public interface IGetSIDIDService {
	
	public String getNewSIDID();
	public String getHyperlinks();

}
