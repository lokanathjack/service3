package com.att.ubm.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class GetSIDIDController implements IGetSIDIDController {
	
	@Autowired
	IGetSIDIDService getSididService;
	
	public GetSIDIDController()
	{
		
	}
	
	public String getNewSIDID()
	{
		System.out.println("Enter into GetSIDIDController::getNewSIDID");
		String sidid=getSididService.getNewSIDID();
		if (sidid!=null) {
				System.out.println("getNewSIDID():"+sidid);
				return sidid;
		}
		return null;
		
	}
	
	@Override
	public String getHyperlinksDetails() {
		return getSididService.getHyperlinks();
	}



	
	
	
}
