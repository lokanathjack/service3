/**
 * 
 */
package com.att.ubm.util;

import org.apache.commons.lang.StringUtils;

import com.att.ubm.model.Description;

/**
 * @author kb942m
 *
 */
public class DescriptionTokenUtil {

	public static Description getDescriptionToken(String tokenLst) {

		Description description = new Description();

		String[] tokenArr = StringUtils.split(tokenLst, ',');
		for (String myTaskInfoToken : tokenArr) {
			String[] splitToken = StringUtils.split(myTaskInfoToken, '=');

			if (splitToken[0].equals("SidId")) {
				description.setSidId(splitToken[1]);
			} else if (splitToken[0].equals("SidDesc")) {
				description.setSidDescription(splitToken[1]);
			} else if (splitToken[0].equals("SidType")) {
				description.setSidType(splitToken[1]);
			} else if (splitToken[0].equals("Creator")) {
				description.setCreator(splitToken[1]);
			} else if (splitToken[0].equals("RequestType")) {
				description.setRequestType(splitToken[1]);
			}

		}

		return description;
	}

}
