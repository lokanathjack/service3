package com.att.ubm.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class GetUIFormFieldsController implements IGetUIFormFileldsController {
	
	@Autowired
	IUIFormFieldService formFieldService;
	
	public GetUIFormFieldsController()
	{
		
	}
	
	@Override
	public String getFieldUINames(String sidType, String pageName,String activityName) {
		return formFieldService.getUIFormFieldsDetalls(sidType, pageName, activityName, null);
	}




	
	
	
}
