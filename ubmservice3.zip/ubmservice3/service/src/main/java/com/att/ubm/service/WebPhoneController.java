package com.att.ubm.service;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.GroupsDetailsModel;
import com.att.ubm.model.RequestorModel;


@Component
public class WebPhoneController implements IWebPhoneController {
	
	@Autowired
	IWebPhoneService phoneService;
	
	public WebPhoneController()
	{
		
	}
	

	@Override
	public RequestorModel getRequestorDetails(String attuid) {
		try {
			System.out.println("Enter into WebPhoneController:::getRequstorDetails"+attuid);
			if(attuid!=null)
			{
				
				RequestorModel value=phoneService.getRequstorDetails(attuid);
			if (value!=null) {
					return value;
			}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<EmployeeDetailsModel> getAllGroupMembers(String groupName) {
		System.out.println("Enter into getAllGroupMembers...."+groupName);
		try {
			return phoneService.getAllGroupMembers(groupName);
			//System.out.println("Siva:\t"+allGroups);
			//allGroups=allGroups.replace("/\\n/g", "\\n");
                   
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Map<String, String> getMouseOver(String screenName) {
		return phoneService.getToolTips(screenName);
	}
	
	@Override
	public String getConfigDetails(String sidType,String pageName,String sidId) {
		
		return phoneService.getConfigKCPNVPDetalls(sidType,pageName,sidId);
	}
}
