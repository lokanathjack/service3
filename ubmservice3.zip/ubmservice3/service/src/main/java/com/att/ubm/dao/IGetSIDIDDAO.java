package com.att.ubm.dao;

import java.util.List;

import com.att.ubm.model.HyperlinksModel;

public interface IGetSIDIDDAO {
	
	public String getNewSIDID();
	public List<HyperlinksModel> getHyperlinksDetails();

}
