package com.att.ubm.service;



public interface IUIFormFieldService {

	public String getUIFormFieldsDetalls(String sidType,String pageName,String activityName,String sidId);
}