/**
 * 
 */
package com.att.ubm.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ubm.cache.UBMCacheManager;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.QUNarrativeModel;

/**
 * @author kb942m
 *
 */
@Component
public class QUNarraitiveController implements IQUNarraitiveController {
	private static final Logger logger = LoggerFactory.getLogger(QUNarraitiveController.class);

	@Autowired
	IQUNarraitiveService quNarraitiveService;
	
	@Autowired
	UBMCacheManager ubmCacheManager;

	public QUNarraitiveController() {

	}

	@Override
	public ApprovalOption getApproverOptions(String approverType) {
		ApprovalOption approvalList = new ApprovalOption();
		try {
			approvalList = ubmCacheManager.getApproverOptionsInfoFromCache(approverType);

		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}

		return approvalList;
	}
	
	@Override
	public String saveNarrativeForm(@RequestBody String quNarrativeString) {
		String retMsg=null;
		System.out.println("input values:\t"+quNarrativeString);
		try {
			retMsg=quNarraitiveService.saveNarrativeForm(quNarrativeString);
		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}
		return retMsg;
	}

	@Override
	public String getNarrativeDetails(String sidId) {
		return quNarraitiveService.getNarrativeFormValues(sidId);
	}

	@Override
	public String getColumnValueFromSidNarr(String sidId, String columnName) {
		System.out.println("============ Entered into getColumnValueFromSidNarr ===== ");
		// TODO Auto-generated method stub
		return quNarraitiveService.getColumnValueFromSidNarr(sidId, columnName);
	}


}
