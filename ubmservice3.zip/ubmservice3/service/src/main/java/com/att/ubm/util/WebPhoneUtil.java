package com.att.ubm.util;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;


public class WebPhoneUtil 
{
	private static String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
	private static String MY_HOST = "ldap://ldap.webphone.att.com:389";
	private static String MY_SEARCHBASE = "ou=people, o=att, c=us";
	private static Hashtable<String,String> env ;
	private static DirContext ctx; 
	private static SearchControls constraints;
	static
	{
		env = new Hashtable<String,String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, INITCTX);
		env.put(Context.PROVIDER_URL, MY_HOST);
		
		/* specify search constraints to search subtree */
		constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		
	}
	@SuppressWarnings("all")
	private static String getAttribute( String attId, String attribute )throws Exception
	{
		/* get a handle to an Initial DirContext */
		try 
		{
			ctx = new InitialDirContext(env);
		}
		catch (NamingException e) 
		{		
			e.printStackTrace();
		}
		String MY_FILTER = "(a1=" + attId + ")";
		String attributeValue = null;
		NamingEnumeration results = ctx.search(MY_SEARCHBASE, MY_FILTER, constraints);
		
		while (results != null && results.hasMore()) 
		{
			SearchResult si = (SearchResult) results.next();
			
			Attributes attrs = si.getAttributes();
			if (attrs != null && attrs.get(attribute)!=null) 
			{
				Attribute attr = attrs.get(attribute);
				attributeValue =  (String)attr.get();
				break;
			}
		}
		return attributeValue;
	}
	@SuppressWarnings("all")
	private static String getAttrValForMultipleUser( String filterCriteria, String attribute )throws Exception
	{
		/* get a handle to an Initial DirContext */
		try 
		{
			ctx = new InitialDirContext(env);
		}
		catch (NamingException e) 
		{		
			e.printStackTrace();
		}
		
		constraints.setReturningAttributes(new String [] {"mgrid"});
		String MY_FILTER = "(|"+ filterCriteria +")";		
		String attributeValue = null;
		NamingEnumeration results = ctx.search(MY_SEARCHBASE, MY_FILTER, constraints);
		StringBuilder sb = new StringBuilder ();
		SearchResult si = null;
		Attributes attrs = null;
		Attribute attr = null;
		
		while (results != null && results.hasMore()) 
		{
			si = (SearchResult) results.next();
			
			attrs = si.getAttributes();
			
			if (attrs != null) 
			{
				attr = attrs.get(attribute);
				if (attr != null)
					attributeValue =  (String)attr.get();				
			}
			if (Validator.isValidString(attributeValue)) 
			{				
				if (sb.length() > 0) 
				{
					if (!sb.toString().contains(attributeValue)) 
					{
						sb.append(",");	
						attributeValue = attributeValue + "@att.com";
						sb.append(attributeValue);
					}
				} 
				else 
				{
					attributeValue = attributeValue + "@att.com";
					sb.append(attributeValue);
				}
			}
		}
		return sb.toString();
	}
	
	
	
	public static String getMail(String attId) throws Exception
	{
		return getAttribute( attId , "mail" );
	} 
	public static String getTelephoneNumber(String attId) throws Exception
	{
		return getAttribute( attId , "telephoneNumber" );
	}
	public static String getTitle(String attId) throws Exception
	{
		return getAttribute( attId , "jtname" );
	}
	
	
	public static void main(String[] args) {
		try {
			System.out.println(getTitle("sm802k"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
