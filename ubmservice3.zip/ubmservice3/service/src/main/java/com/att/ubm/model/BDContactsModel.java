package com.att.ubm.model;

import java.io.Serializable;

public class BDContactsModel implements Serializable {
	
	private String bdPhone;
	private String bdEmailId;
	public String getBdPhone() {
		return bdPhone;
	}
	public void setBdPhone(String bdPhone) {
		this.bdPhone = bdPhone;
	}
	public String getBdEmailId() {
		return bdEmailId;
	}
	public void setBdEmailId(String bdEmailId) {
		this.bdEmailId = bdEmailId;
	}
	
	
	

}
