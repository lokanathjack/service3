package com.att.ubm.model;

import java.io.Serializable;

public class RequestorModel implements Serializable {
	
	private String requstorPhone;
	private String requestorEmailId;
	public String getRequstorPhone() {
		return requstorPhone;
	}
	public void setRequstorPhone(String requstorPhone) {
		this.requstorPhone = requstorPhone;
	}
	public String getRequestorEmailId() {
		return requestorEmailId;
	}
	public void setRequestorEmailId(String requestorEmailId) {
		this.requestorEmailId = requestorEmailId;
	}
	
	
	

}
