package com.att.ubm.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "actors")
public class MyTasksModel {
	
	private long no;
	private String taskName;
	private String creator;
	private String requestType;
	private String sidId;
	private String sidDescription;
	private String requestNumber;
	private String impactedGroupName;
	private String assignmentDate;
	private String dueDate;
	
	public MyTasksModel()
	{
		
	}
	@XmlElement
	public long getNo() {
		return no;
	}

	public void setNo(long no) {
		this.no = no;
	}
	@XmlElement
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	@XmlElement
	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}
	@XmlElement
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	@XmlElement
	public String getSidId() {
		return sidId;
	}

	public void setSidId(String sidId) {
		this.sidId = sidId;
	}
	@XmlElement
	public String getSidDescription() {
		return sidDescription;
	}

	public void setSidDescription(String sidDescription) {
		this.sidDescription = sidDescription;
	}
	@XmlElement
	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}
	@XmlElement
	public String getImpactedGroupName() {
		return impactedGroupName;
	}

	public void setImpactedGroupName(String impactedGroupName) {
		this.impactedGroupName = impactedGroupName;
	}
	@XmlElement
	public String getAssignmentDate() {
		return assignmentDate;
	}

	public void setAssignmentDate(String assignmentDate) {
		this.assignmentDate = assignmentDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	
	
	

}
