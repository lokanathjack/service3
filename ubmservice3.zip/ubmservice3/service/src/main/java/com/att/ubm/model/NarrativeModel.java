package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;

public class NarrativeModel implements Serializable {
	
	private String requestorName;
	private RequestorModel requestor;
	private String bdContactName;
	private BDContactsModel bdContact;
	private String requestedDate;
	private String sidRestriction;
	private String telegenceImpacted;
	private String itProposedDate;
	private String titanEnablerProposedImplementationDate;
	private String narrativeProvidedBy;
	private String narrativeTimeAndDateProvided;
	private List<String> markets;
	private String narrativeText;
	private String titanEnabledImpacted;
	private List<String> productApprovers;
	private List<String> requiredCoreApproval;
	private String marketNarComments;
	private String friendlyName;
	private String impactWifi;
	private String marketNarOverallReq;
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public RequestorModel getRequestor() {
		return requestor;
	}
	public void setRequestor(RequestorModel requestor) {
		this.requestor = requestor;
	}
	public String getBdContactName() {
		return bdContactName;
	}
	public void setBdContactName(String bdContactName) {
		this.bdContactName = bdContactName;
	}
	
	
	public BDContactsModel getBdContact() {
		return bdContact;
	}
	public void setBdContact(BDContactsModel bdContact) {
		this.bdContact = bdContact;
	}
	public String getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}
	public String getSidRestriction() {
		return sidRestriction;
	}
	public void setSidRestriction(String sidRestriction) {
		this.sidRestriction = sidRestriction;
	}
	public String getTelegenceImpacted() {
		return telegenceImpacted;
	}
	public void setTelegenceImpacted(String telegenceImpacted) {
		this.telegenceImpacted = telegenceImpacted;
	}
	public String getItProposedDate() {
		return itProposedDate;
	}
	public void setItProposedDate(String itProposedDate) {
		this.itProposedDate = itProposedDate;
	}
	public String getTitanEnablerProposedImplementationDate() {
		return titanEnablerProposedImplementationDate;
	}
	public void setTitanEnablerProposedImplementationDate(String titanEnablerProposedImplementationDate) {
		this.titanEnablerProposedImplementationDate = titanEnablerProposedImplementationDate;
	}
	public String getNarrativeProvidedBy() {
		return narrativeProvidedBy;
	}
	public void setNarrativeProvidedBy(String narrativeProvidedBy) {
		this.narrativeProvidedBy = narrativeProvidedBy;
	}
	public String getNarrativeTimeAndDateProvided() {
		return narrativeTimeAndDateProvided;
	}
	public void setNarrativeTimeAndDateProvided(String narrativeTimeAndDateProvided) {
		this.narrativeTimeAndDateProvided = narrativeTimeAndDateProvided;
	}
	public List<String> getMarkets() {
		return markets;
	}
	public void setMarkets(List<String> markets) {
		this.markets = markets;
	}
	
	public String getNarrativeText() {
		return narrativeText;
	}
	public void setNarrativeText(String narrativeText) {
		this.narrativeText = narrativeText;
	}
	public String getTitanEnabledImpacted() {
		return titanEnabledImpacted;
	}
	public void setTitanEnabledImpacted(String titanEnabledImpacted) {
		this.titanEnabledImpacted = titanEnabledImpacted;
	}
	
	public List<String> getProductApprovers() {
		return productApprovers;
	}
	public void setProductApprovers(List<String> productApprovers) {
		this.productApprovers = productApprovers;
	}
	public List<String> getRequiredCoreApproval() {
		return requiredCoreApproval;
	}
	public void setRequiredCoreApproval(List<String> requiredCoreApproval) {
		this.requiredCoreApproval = requiredCoreApproval;
	}
	public String getMarketNarComments() {
		return marketNarComments;
	}
	public void setMarketNarComments(String marketNarComments) {
		this.marketNarComments = marketNarComments;
	}
	public String getFriendlyName() {
		return friendlyName;
	}
	public void setFriendlyName(String friendlyName) {
		this.friendlyName = friendlyName;
	}
	public String getImpactWifi() {
		return impactWifi;
	}
	public void setImpactWifi(String impactWifi) {
		this.impactWifi = impactWifi;
	}
	public String getMarketNarOverallReq() {
		return marketNarOverallReq;
	}
	public void setMarketNarOverallReq(String marketNarOverallReq) {
		this.marketNarOverallReq = marketNarOverallReq;
	}
	
	
	
	
	

}
