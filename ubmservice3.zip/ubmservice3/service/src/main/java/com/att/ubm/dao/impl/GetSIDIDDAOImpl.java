package com.att.ubm.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IGetSIDIDDAO;
import com.att.ubm.dao.IMyTaskDAO;
import com.att.ubm.model.HyperlinksModel;
import com.att.ubm.model.MyTasksModel;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.LabelCacheUtil;

import org.springframework.beans.factory.annotation.Qualifier;


@Repository
public class GetSIDIDDAOImpl implements IGetSIDIDDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	
	
	


	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}


	@Override
	public String getNewSIDID() {
		String sqlStmt = null;
		String sidId;
		try {
			sqlStmt = "select SID_ID_SEQ.nextval from dual";
			int seqVal = jdbcTemplate.queryForObject(
					sqlStmt, Integer.class);
			sidId=DecoratorDate.dateToStringInFormat(new java.util.Date(), "yyyyMMdd", null) + DecoratorDate.formatNumber(seqVal, "000");
			System.out.println("Sididid:\t"+sidId);
			return sidId;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<HyperlinksModel> getHyperlinksDetails() {
		String sql = "SELECT UBM_KEY, UBM_KEY_DESCRIPTION,LINK_URL FROM UBM_HYPERLINKS";
		List<HyperlinksModel> hyperlinksList = new ArrayList<HyperlinksModel>();
		try {
			System.out.println("Enter into getHyperlinksDetails");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql);
			HyperlinksModel hyperlinksModel=null;
			while (sqlRowSet.next()) {
				hyperlinksModel=new HyperlinksModel();
				hyperlinksModel.setUbmHyperKey(LabelCacheUtil.isNull(sqlRowSet.getString("UBM_KEY")));
				hyperlinksModel.setUbmHyperDescription(LabelCacheUtil.isNull(sqlRowSet.getString("UBM_KEY_DESCRIPTION")));
				hyperlinksModel.setUbmHyperURL(LabelCacheUtil.isNull(sqlRowSet.getString("LINK_URL")));
				hyperlinksList.add(hyperlinksModel);
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return hyperlinksList;
	}

	

}
