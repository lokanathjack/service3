package com.att.ubm.service;


public interface IFileNetService {

	public String getFileNetInfo(String appName,String sidId, String folderName);
	public int getFileCount(String appName,String sidId, String folderName);
}