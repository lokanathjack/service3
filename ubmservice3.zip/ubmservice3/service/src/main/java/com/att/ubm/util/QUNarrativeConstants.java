package com.att.ubm.util;


/**
 * @author kb942m
 *
 */
public class QUNarrativeConstants {
	
	public static final String PRODUCT = "PRODUCT";
	
	public static final String CHANNEL = "CHANNEL";
	
	public static final String ALTERNATE = "ALTERNA";
	
	public static final String QUICKUPDATE = "QUICKUPDATE";
	
	public static final String VOICE = "Voice";
	
	public static final String QU_TABLE_NAME = "SID_NARR";
	public static final String QU_LIST_TABLE_NAME = "SID_NARR_LIST";
	
	
	

}
