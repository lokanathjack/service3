/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author kb942m
 *
 */
public class ApprovalName implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8108731862870626059L;

	private String firstName;

	private String lastName;

	private String attId;

	private String name;

	private String keyVal;
	
	private long startDisplay;
	
	private long endDisplay;	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getAttId() {
		return attId;
	}

	public void setAttId(String attId) {
		this.attId = attId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKeyVal() {
		return keyVal;
	}

	public void setKeyVal(String keyVal) {
		this.keyVal = keyVal;
	}	
	

	public long getStartDisplay() {
		return startDisplay;
	}

	public void setStartDisplay(long startDisplay) {
		this.startDisplay = startDisplay;
	}

	public long getEndDisplay() {
		return endDisplay;
	}

	public void setEndDisplay(long endDisplay) {
		this.endDisplay = endDisplay;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
