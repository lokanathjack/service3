package com.att.ubm.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ubm.service.IFileNetService;


@Component
public class FileNetController implements IFileNetController {
	
	@Autowired
	IFileNetService fileNetService;
	
	public FileNetController()
	{
		
	}

	

	@Override
	public String getFilenetNavigateURL(String appName,String sidId, String folderName) {
		return fileNetService.getFileNetInfo(appName, sidId, folderName);
	}

	@Override
	public int getFileCount(String appName,String sidId, String folderName) {
		return fileNetService.getFileCount(appName, sidId, folderName);
	}

	
	
}
