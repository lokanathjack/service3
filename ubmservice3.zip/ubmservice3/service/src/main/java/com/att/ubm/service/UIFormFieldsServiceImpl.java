package com.att.ubm.service;


import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.SystemPropertyUtils;

import com.att.ubm.dao.IGetUIFormFieldsDAO;

/*import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;*/

import com.att.ubm.model.UIFormFieldsModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.att.aft.dme2.internal.gson.Gson;
import org.json.simple.JSONObject;

@Service
public class UIFormFieldsServiceImpl implements IUIFormFieldService {
	
	@Autowired
	IGetUIFormFieldsDAO uiFormFieldsDAO;

	
	
	 @Override
		public String getUIFormFieldsDetalls(String sidType,String pageName,String activityType,String sidId) {
			
			try {
				 List<UIFormFieldsModel> listofValues=uiFormFieldsDAO.getUIFormFieldsDetalls(activityType);
				 System.out.println("listofValues:\t"+listofValues.size());
				if(listofValues!=null)
				{
					//Map<String,List<UIFormFieldsModel>> sortedBySidid=getSortBySidid(listofValues,sidId);
					//if(sortedBySidid!=null)
					{
					return getUIFieldsJsonString(sidType,pageName,activityType,sidId,listofValues);
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	    
	    private Map<String,List<UIFormFieldsModel>> getSortBySidid(List<UIFormFieldsModel> listofValues,String sidId)
	    {
	    	Map<String,List<UIFormFieldsModel>> valueNameObject=null;
	    	try {
	    		valueNameObject=new LinkedHashMap<String,List<UIFormFieldsModel>>();
				for(UIFormFieldsModel obj:listofValues)
				{
					
					if(Long.parseLong(sidId)>=obj.getStartDate() && Long.parseLong(sidId)<=obj.getEndDate())
					{
						String key=obj.getUbmKey();
						if(valueNameObject.containsKey(key))
						{
							List<UIFormFieldsModel> tempList=valueNameObject.get(key);
							UIFormFieldsModel model=new UIFormFieldsModel();
							model.setUbmKey(model.getUbmKey());
							model.setScreenName(model.getScreenName());
							model.setUbmKeyDescription(model.getUbmKeyDescription());
							model.setToolTip(model.getToolTip());
							model.setisEnabled(model.isEnabled());
							model.setFieldVisibility(model.isFieldVisibility());
							model.setFieldRegex(model.getFieldRegex());
							model.setStartDate(model.getStartDate());
							model.setEndDate(model.getEndDate());
							
							tempList.add(model);
							valueNameObject.put(key, tempList);
						}
						else
						{
							List<UIFormFieldsModel> lstValue=new ArrayList<UIFormFieldsModel>();
							UIFormFieldsModel model=new UIFormFieldsModel();
							model.setUbmKey(model.getUbmKey());
							model.setScreenName(model.getScreenName());
							model.setUbmKeyDescription(model.getUbmKeyDescription());
							model.setToolTip(model.getToolTip());
							model.setisEnabled(model.isEnabled());
							model.setFieldVisibility(model.isFieldVisibility());
							model.setFieldRegex(model.getFieldRegex());
							model.setStartDate(model.getStartDate());
							model.setEndDate(model.getEndDate());
							lstValue.add(model);
							valueNameObject.put(key, lstValue);
						}
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	return valueNameObject;
	    }
	    
	    public String getUIFieldsJsonString(String sidType,String pageName,String activityType,String sidId, List<UIFormFieldsModel> listofValues) {
			System.out.println("Enter into here");
			
			
			ObjectMapper objectMapper = new ObjectMapper();
	    	//Set pretty printing of json
	    	//objectMapper.enable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
			
			//JSONObject tempResponseDetailsJson = new JSONObject();
	    	 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    	//Define map which will be converted to JSON
	    	 
	    	 JSONObject responseDetailsJson = new JSONObject();
				responseDetailsJson.put("sidType", sidType);
				responseDetailsJson.put("activityName", activityType);
				responseDetailsJson.put("pageName", pageName);
				
				/* org.json.simple.JSONArray ja1 = new org.json.simple.JSONArray();
				 ja1.add(responseDetailsJson);*/
				
					/*array.add(responseDetailsJson);
					array.add(responseDetailsJson1);*/
				
				// array.add(new StringBuffer().append("sidType").append(sidType));
				// array.add(new StringBuffer().append("pageName").append(pageName));
	    	 
	    	 
	    	 String arrayToJson="";
	    	 //System.out.println("Sorted list size:\t"+details.size());
	    	 System.out.println("Result:\t"+listofValues.size());
	    	
	    	try {
	    		if(listofValues!=null && listofValues.size()>0)
	    		{
	    			JSONObject tempResponseDetailsJson = new JSONObject();
	    			//dbValues.append(entry.getKey());
	    			for(UIFormFieldsModel model:listofValues)
	    			{
	    				
	    				arrayToJson = objectMapper.writeValueAsString(model);
	    				//System.out.println("Object Mapper:\t"+arrayToJson);
	    				tempResponseDetailsJson.put(model.getUbmKeyDescription(), arrayToJson);
	    				//ja.add(arrayToJson);
	    				//newList.add(arrayToJson);
	    				//System.out.println("Array:"+ja);
	    				//System.out.println("List:\t"+newList);
	    				//dbValues.append(arrayToJson);
	    			}
	    			
	    			responseDetailsJson.put("ubmFields", tempResponseDetailsJson);
	    			//System.out.println(responseDetailsJson);
	    			
	    		}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
	    	
	    	//System.out.println("tempResponseDetailsJson:\t"+tempResponseDetailsJson);
	    	String tempStr=null;
					//responseDetailsJson.put(sb.toString(), ja.toString());
					/*JSONObject json=new JSONObject();
					json.put(responseDetailsJson, tempResponseDetailsJson);*/
					//System.out.println(json.toJSONString());
					tempStr=responseDetailsJson.toJSONString();
					tempStr = new Gson().toJson(responseDetailsJson);
					System.out.println("tempStr:\t"+responseDetailsJson);
				
	    	return tempStr;
	    	
	    
	    	
	    
		}
	    

	
	
}
