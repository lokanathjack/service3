package com.att.ubm.dao;

import java.util.List;
import java.util.Map;

import com.att.ubm.model.ConfigKCPNVPModel;
import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.UIFormFieldsModel;

public interface IGetUIFormFieldsDAO {
	
	public List<UIFormFieldsModel> getUIFormFieldsDetalls(String activityType);
	

}
