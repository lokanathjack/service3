package com.att.ubm.dao;


import com.att.ubm.model.MyTasksModel;

public interface IMyTaskDAO {
	
	public MyTasksModel getTaskInfo(String sidId);

}
