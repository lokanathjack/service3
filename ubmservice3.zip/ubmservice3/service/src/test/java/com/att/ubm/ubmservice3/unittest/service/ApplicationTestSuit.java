package com.att.ubm.ubmservice3.unittest.service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.att.ubm.ubmservice3.unittest.service.HelloTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ 
	HelloTest.class,
})
public class ApplicationTestSuit {
}